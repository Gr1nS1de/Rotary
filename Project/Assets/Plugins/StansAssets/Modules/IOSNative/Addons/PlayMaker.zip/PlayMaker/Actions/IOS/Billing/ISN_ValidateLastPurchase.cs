using UnityEngine;
using System.Collections;
using SA.IOSNative.StoreKit;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Aaction will start purchase flow on device. In Editor mode Success event will fired immediately")]
	public class ISN_ValidateLastPurchase : FsmStateAction {
		
		
		[Tooltip("Event fired when Store Kit initlization is complete")]
		public FsmEvent successEvent;
		
		[Tooltip("Event fired when Store Kit initlization is failed")]
		public FsmEvent failEvent;

		public bool useSendBoxUrl = true;


		public FsmInt status;
		public FsmString receipt;
		public FsmString originalJSON;
		

		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			string url = PaymentManager.APPLE_VERIFICATION_SERVER;

			if(useSendBoxUrl) {
				url = PaymentManager.SANDBOX_VERIFICATION_SERVER;
			}


			PaymentManager.OnVerificationComplete += HandleOnVerificationComplete;
			PaymentManager.Instance.VerifyLastPurchase(url);

			
		}

		void HandleOnVerificationComplete (VerificationResponse resp){
			PaymentManager.OnVerificationComplete -= HandleOnVerificationComplete;
			
			
			status.Value 		= resp.Status;
			receipt.Value 		= resp.Receipt;
			originalJSON.Value 	= resp.OriginalJSON;
			
			if(resp.Status == 0) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}
			
			Finish();
		}
		

		
	}
}


