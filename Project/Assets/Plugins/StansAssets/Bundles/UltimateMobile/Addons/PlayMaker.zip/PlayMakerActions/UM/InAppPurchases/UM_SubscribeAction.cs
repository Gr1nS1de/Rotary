﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Ultimate Mobile - InAppPurchases")]
	[Tooltip("Action will start subscription flow on device. In Editor mode Subscribed event will fired immediately")]
	public class UM_SubscribeAction : FsmStateAction {
		[Tooltip("Event fired when InApp subscription is completed")]
		public FsmEvent subscribedEvent;
		
		[Tooltip("Event fired when InApp subscription is failed")]
		public FsmEvent failEvent;
		
		[Tooltip("Subscription Id")]
		public FsmString SubscriptionID  = "";

		public override void OnEnter() {
			
			if (!UM_InAppPurchaseManager.instance.IsConnected) {
				UM_InAppPurchaseManager.Client.OnServiceConnected += OnStoreInitComplete;
				UM_InAppPurchaseManager.instance.Connect();
			} else {
				OnBillingInited();
			}
			
		}
		
		private void OnBillingInited() { 
			UM_InAppPurchaseManager.Client.OnPurchaseFinished += OnTransactionComplete;
			UM_InAppPurchaseManager.instance.Subscribe(SubscriptionID.Value);


		}
		
		private void OnTransactionComplete (UM_PurchaseResult result) {

			if(!result.product.id.Equals(SubscriptionID.Value)) {
				return;
			}

			UM_InAppPurchaseManager.Client.OnPurchaseFinished -= OnTransactionComplete;

			if (result.isSuccess) {
				Fsm.Event(subscribedEvent);
			} else {
				Fsm.Event(failEvent);
			}
			
			Finish();
		}

		private void OnStoreInitComplete (UM_BillingConnectionResult res) {
			UM_InAppPurchaseManager.Client.OnServiceConnected -= OnStoreInitComplete;
			if(res.isSuccess) {
				OnBillingInited();
			} else {
				Fsm.Event(failEvent);
				Finish();
			}
		}
	}
}
