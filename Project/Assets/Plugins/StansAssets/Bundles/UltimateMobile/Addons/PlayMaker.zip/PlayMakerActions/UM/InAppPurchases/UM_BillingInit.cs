﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Ultimate Mobile - InAppPurchases")]
	[Tooltip("Initialize billing. Best practice to do this on appplicaton start")]
	public class UM_BillingInit : FsmStateAction {

		[Tooltip("Event fired when billing initlization is complete")]
		public FsmEvent successEvent;
		
		[Tooltip("Event fired when billing initlization is failed")]
		public FsmEvent failEvent;


		public override void Reset() {
			
		}		
		
		public override void OnEnter() {

			if(UM_InAppPurchaseManager.instance.IsConnected) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			UM_InAppPurchaseManager.Client.OnServiceConnected += OnStoreInitComplete;
			UM_InAppPurchaseManager.instance.Connect ();
		}
		
		private void OnStoreInitComplete (UM_BillingConnectionResult res) {
			UM_InAppPurchaseManager.Client.OnServiceConnected -= OnStoreInitComplete;
			if(res.isSuccess) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}
			
			
			Finish();
		}
	}
}
